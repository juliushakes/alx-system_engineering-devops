This section is about shell variable expansions
