About shell redirections.
