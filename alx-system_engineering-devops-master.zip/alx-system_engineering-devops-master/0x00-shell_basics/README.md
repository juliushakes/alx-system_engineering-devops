File not empty
